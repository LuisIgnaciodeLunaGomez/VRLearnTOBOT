﻿/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingeniería Informática - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna Gómez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 01/04/2025
 * 
 * Versión: 1.0.0
 * 
 * Descripción: 
 */


using System;
using System.Text;
using System.Text.RegularExpressions;

public partial class CSharpGenerator
{
    [CodeGenerator(BlockType = "controls_repeat")]
    private string Control_Repeat(BlockModel block)
    {
        int repeats = int.Parse(block.GetFieldValue("TIMES"));
        string branch = CSharp.Generator.StatementToCode(block, "DO", "");
        string loopVar = CSharp.VariableNames.GetDistinctName("count");
        string code = string.Format("for (int {0} = 0; {0} < {1}; ++{0})\n{{\n    {2}\n}}\n", loopVar, repeats, branch);
        return code;
    }

    [CodeGenerator(BlockType = "controls_repeat_ext")]
    private string Control_RepeatExt(BlockModel block)
    {
        string repeats = CSharp.Generator.ValueToCode(block, "TIMES", CSharp.ORDER_NONE, "0");
        int repeatsInt = 0;
        if (int.TryParse(repeats, out repeatsInt))
            repeats = repeatsInt.ToString();
        else
            repeats = string.Format("(int)({0})", repeats);
        string branch = CSharp.Generator.StatementToCode(block, "DO", "");
        string loopVar = CSharp.VariableNames.GetDistinctName("count");
        string code = string.Format("for (int {0} = 0; {0} < {1}; ++{0})\n{{\n    {2}\n}}\n", loopVar, repeats, branch);
        return code;

    }

    [CodeGenerator(BlockType = "controls_whileUntil")]
    private string Control_WhileUntil(BlockModel block)
    {
        bool until = block.GetFieldValue("MODE").Equals("UNTIL");
        string arg0 = CSharp.Generator.ValueToCode(block, "BOOL",
         until ? CSharp.ORDER_UNARY : CSharp.ORDER_NONE, "false");
        string branch = CSharp.Generator.StatementToCode(block, "DO", "");
        branch = CSharp.Generator.AddLoopTrap(branch, block.ID);
        if (until)
        {
            arg0 = "!" + arg0;
        }
        return string.Format("while ({0})\n{{\n    {1}}}\n", arg0, branch);
    }

    [CodeGenerator(BlockType = "controls_for")]
    private string Control_For(BlockModel block)
    {
        string variable0 = CSharp.VariableNames.GetName(block.GetFieldValue("VAR"), "VARIABLE");
        string from = CSharp.Generator.ValueToCode(block, "FROM", CSharp.ORDER_NONE, "0");
        string to = CSharp.Generator.ValueToCode(block, "TO", CSharp.ORDER_NONE, "0");
        string increment = CSharp.Generator.ValueToCode(block, "BY", CSharp.ORDER_NONE, "1");
        string branch = CSharp.Generator.StatementToCode(block, "DO", "");
        branch = CSharp.Generator.AddLoopTrap(branch, block.ID);

        string incValue;
        float fromValue, toValue, incrementVar;
        if (float.TryParse(from, out fromValue) && float.TryParse(to, out toValue) && float.TryParse(increment, out incrementVar))
        {
            bool up = fromValue <= toValue;
            float step = Math.Abs(incrementVar);
            incValue = up ? "+= " + step : "-= " + step;
            string code = string.Format("for (float {0} = {1}, {0} {2} {3}, {0} {4})\n{{\n    {5}\n}}\n",
                                        variable0, from, up ? "<=" : ">=", to, incValue, branch);
            return code;
        }
        else
        {
            throw new Exception("input value \"FROM\" \"TO\" \"BY\" of block controls_for must be a number type.");
        }
    }

    [CodeGenerator(BlockType = "controls_forEach")]
    private string Control_ForEach(BlockModel block)
    {
        string variable0 = CSharp.VariableNames.GetName(block.GetFieldValue("VAR"), "VARIABLE");
        string arg0 = CSharp.Generator.ValueToCode(block, "LIST", CSharp.ORDER_NONE, "new System.Collections.Generic.List<float>()");
        string branch = CSharp.Generator.StatementToCode(block, "DO", "\n");

        StringBuilder code = new StringBuilder();

        string listVar = arg0;
        Regex regex = new Regex(@"^\w+$");
        if (!regex.IsMatch(arg0))
        {
            listVar = CSharp.VariableNames.GetDistinctName(variable0 + "_list");
            code.Append(string.Format("var {0} = {1};\n", listVar, arg0));
        }

        code.Append(string.Format("foreach (var {0} in {1})\n{{\n    {2}\n}}\n", variable0, listVar, branch));
        return code.ToString();
    }

    [CodeGenerator(BlockType = "controls_flow_statements")]
    private string Control_FlowStatement(BlockModel block)
    {
        switch (block.GetFieldValue("FLOW"))
        {
            case "BREAK": return "break;\n";
            case "CONTINUE": return "continue;\n";
        }
        throw new Exception("Unknown flow statement.");
    }
}
