﻿/****************************************************************************

Collections for some definitions for code generations and interpreting

Copyright 2016 sophieml1989@gmail.com

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

****************************************************************************/

using System;
using System.ComponentModel;


    public enum CodeName
    {
        CSharp,
        Lua,
    }

    public enum ControlFlowType
    {
        None,
        Break,
        Continue,
    }

    [AttributeUsage(AttributeTargets.Method, Inherited = false)]
    public sealed class CodeGeneratorAttribute : Attribute
    {
        [Description("method for generating block code string")]
        public CodeGeneratorAttribute() {}
        public string BlockType { get; set; }
    }

[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public sealed class CodeInterpreterAttribute : Attribute
{
    [Description("method for interpreting to implement block code")]
    public CodeInterpreterAttribute() { }
    public string BlockType { get; set; }
}
