/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha:01/04/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n: Integraci�n de la estructura de Ublockly dentro del proyecto por semejanza con ScratchBlocks. 
 */

using System.Collections.Generic;
using System;
using UnityEngine;

[Serializable]
public class ToolboxBlockCategory
{
    public string CategoryName;
    //public string Colour;
    public string Custom;
    public string BlockTypePrefix;
    public List<string> BlockList;

    [NonSerialized] private bool mInited = false;

    public Color Color { get; private set; }


    /// <summary>
    /// Inicializa la categor�a con el Color procesado externamente.
    /// Llamado desde UICanvasView.InitializeCategoryColors despu�s de leer Categories.xml.
    /// </summary>
    /// <param name="categoryColor">El Color real para esta categor�a.</param>
    public void Init(Color categoryColor) 
    {
        if (mInited) return;
        this.Color = categoryColor; 
        if (BlockList == null) BlockList = new List<string>();

        mInited = true;
    }



}