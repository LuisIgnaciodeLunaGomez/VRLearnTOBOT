/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha:01/04/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n: Integraci�n de la estructura de Ublockly dentro del proyecto por semejanza con ScratchBlocks.
 */

using System;
using Newtonsoft.Json.Linq;

public class ScratchBlocks
{
 
    public static void Init()
    {
        BlockResMgr.Get().LoadI18n();
        BlockDefinition.LoadAllDefinitionsFromXml("XML/Blocks");
    }

    
    public static void Dispose()
    {
        BlockFactory.Instance.Clear();
        I18n.Dispose();
    }

}
