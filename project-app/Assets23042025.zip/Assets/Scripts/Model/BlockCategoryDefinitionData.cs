/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 27/03/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n: 
 */



using System.Collections.Generic;

public class BlockCategoryDefinitionData 
{
    public string category;
    public List<BlockDefinition> blocks;
}//Fin BlockCategoryDefinitionData