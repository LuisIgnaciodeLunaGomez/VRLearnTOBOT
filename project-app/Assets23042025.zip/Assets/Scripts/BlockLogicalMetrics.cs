/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 27/03/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n: 
 */


public static class BlockLogicalMetrics
{
    public static int OutputConnectionWidth = 10;
    public static int BlockHeight = 30; 
    public static int NotchOffsetHorizontal = 15;
    public static int DefaultInputAttachWidth = 50;

}//Fin BlocklogicalMetrics