/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 01/04/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n:
 */

public static class BlockInputType
{
    public const string Value = "input_value";
    public const string Statement = "input_statement";
    public const string Dummy = "input_dummy"; 
}