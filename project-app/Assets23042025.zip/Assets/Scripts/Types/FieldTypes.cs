/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 01/04/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n:
 */

public static class FieldTypes
{
    public const string Label = "field_label";
    public const string TextInput = "field_input";
    public const string Number = "field_number";
    public const string Dropdown = "field_dropdown";
    public const string Variable = "field_variable";
    public const string Checkbox = "field_checkbox";
    public const string Image = "field_image";
    // public const string Angle = "field_angle";
    // public const string Colour = "field_colour";

}