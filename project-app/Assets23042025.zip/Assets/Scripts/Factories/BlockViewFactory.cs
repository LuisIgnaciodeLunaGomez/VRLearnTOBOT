/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 22/02/2025
 * 
 * Versi�n: 2.0.2
 * 
 * Descripci�n: Clase que crea las vistas de los bloques y las plantillas de bloques cargando el prefab correcto seg�n la informaci�n
 */

using System;
using UnityEngine;
public static class BlockViewFactory
{
    /// <summary>
    /// Crea y configura la vista para un BlockModel dado.
    /// Carga el prefab usando convenci�n de nombres (o BlockResMgr), lo instancia,
    /// obtiene el componente BlockView y llama a su BindModel.
    /// </summary>
    /// <param name="blockModel">El modelo de datos del bloque a visualizar.</param>
    /// <param name="sourceToolbox">Referencia al Toolbox (para obtener WorkspaceView y Color).
    /// Puede ser null si se crea un bloque directamente en el workspace sin pasar por el toolbox,
    /// en cuyo caso se intentar� obtener el WorkspaceView activo.</param>
    /// <returns>La BlockView creada y vinculada, o null si falla.</returns>
    public static BlockView CreateView(BlockModel blockModel, BlockListView sourceToolbox )
    {
        if (blockModel == null)
        {
            Debug.LogError("BlockViewFactory.CreateView: BlockModel is null!");
            return null;
        }

        // Obtener la referencia necesaria a WorkSpaceView
        WorkSpaceView workspaceView = WorkSpaceView.Active; 
        if (workspaceView == null && sourceToolbox is BlockListView scrollList)
        {
            workspaceView = scrollList.WorkspaceViewForFactory; 
        }
        if (workspaceView == null)
        {
              Debug.LogWarning($"BlockViewFactory: Could not get WorkspaceView for block {blockModel.Type}. Some interactions might fail if it's not a template.");

        }

        //  Carga e Instanciaciaci�n del Prefab 
        BlockView blockView = null;
        GameObject blockInstance = null;

        // 1. Obtener el Prefab 
        string blockType = blockModel.Type;
        GameObject blockPrefab = BlockResMgr.Get()?.LoadBlockViewPrefab(blockType);

        if (blockPrefab == null)
        {
            Debug.LogError($"BlockViewFactory: Prefab NOT FOUND for block type '{blockType}'. Check BlockResSettings config or Resources/Prefabs/Blocks path.", workspaceView?.gameObject);
            return null;
        }

        // 2. Instanciar el Prefab encontrado
        try
        {
            // Instanciar sin padre inicial. 
            blockInstance = GameObject.Instantiate(blockPrefab);
            blockInstance.name = $"BlockView_{blockType}_{blockModel.ID}"; 

            // Obtener el componente BlockView del Prefab instanciado
            blockView = blockInstance.GetComponent<BlockView>();

            if (blockView == null)
            {
                Debug.LogError($"BlockViewFactory: Prefab for '{blockType}' ({blockPrefab.name}) IS MISSING the BlockView component! Fix the prefab.", blockPrefab);
                GameObject.Destroy(blockInstance); 
                return null;
            }
        }
        catch (Exception e)
        {
            Debug.LogError($"BlockViewFactory: Error INSTANTIATING prefab '{blockPrefab?.name}' for block '{blockModel.Type}': {e.Message}\n{e.StackTrace}", blockPrefab);
            if (blockInstance != null) GameObject.Destroy(blockInstance); 
            return null;
        }

        //  Vinculaci�n y Configuraci�n Inicial 

        // 3. Vincular la vista creada a su modelo
       
        blockView.BindModel(blockModel, workspaceView); // Pasar modelo y contexto

        // 4. Aplicar Configuraci�n Visual Inicial
     
        Color blockColor = Color.grey; // Default
        if (sourceToolbox != null)
        {
            blockColor = sourceToolbox.GetColorOfBlock(blockType);
        }
        else if (workspaceView?.Toolbox != null)
        { 
            blockColor = workspaceView.Toolbox.GetColorOfBlock(blockType);
        }
        blockView.ChangeBgColor(blockColor);

        return blockView; 
    }
} //Fin clase BlockViewFactory
    