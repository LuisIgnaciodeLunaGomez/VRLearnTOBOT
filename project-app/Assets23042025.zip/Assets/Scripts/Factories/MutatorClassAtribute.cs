/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 01/04/2025
 * 
 * Versi�n: 1.0.0
 * 
 * Descripci�n:
 */



using System;
using System.ComponentModel;


[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public sealed class MutatorClassAttribute : Attribute
{
    [Description("mark class for block mutator")]
    public MutatorClassAttribute() { }

   
    public string MutatorId { get; set; }
}//Fin clase MutatorClassAttribute