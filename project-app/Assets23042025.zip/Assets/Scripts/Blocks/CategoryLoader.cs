/*
 * Trabajo fin de grado 2024-2025 - VRLearnTOBOT
 *
 * Grado en Ingenier�a Inform�tica - Universidad de Burgos
 *
 * Autor: Luis Ignacio de Luna G�mez
 * 
 * email: ldg1008@alu.ubu.es
 * 
 * Fecha: 18/02/2025
 * 
 * Versi�n: 1.0.2
 * 
 * Descripci�n: : Carga la definici�n de las categor�as desde un XML y crea los elementos UI correspondientes en el panel izquierdo.
 */

using System.Collections.Generic;
using System.Xml.Linq;
using UnityEngine;

public static class CategoryLoader
{

    private static Dictionary<string, Color> s_categoryInfoCache = null;
    

    /// Carga la informaci�n Nombre->Color de las categor�as desde el XML especificado.
    /// M�todo rst�tico para ser llamado durante la inicializaci�n.
    /// </summary>
    /// <param name="resourcePath">Ruta del archivo XML dentro de Resources (sin extensi�n).</param>
    /// <returns>Un diccionario mapeando nombre de categor�a a su color.</returns>
    public static Dictionary<string, Color> LoadCategoryInfo(string resourcePath = "XML/Categories")
    {
        var categoryColorMap = new Dictionary<string, Color>(System.StringComparer.OrdinalIgnoreCase); 
        TextAsset xmlData = Resources.Load<TextAsset>(resourcePath);

        if (xmlData == null)
        {
            Debug.LogError($"CategoryLoader.LoadCategoryInfo: No se pudo cargar el archivo XML: {resourcePath}");
            return categoryColorMap; // Devolver diccionario vac�o
        }

        try
        {
            XDocument xmlDoc = XDocument.Parse(xmlData.text);
            XElement rootElement = xmlDoc.Root;
            if (rootElement == null || rootElement.Name.LocalName != "Categories")
            {
                Debug.LogError($"CategoryLoader.LoadCategoryInfo: Archivo XML '{resourcePath}' no contiene la etiqueta ra�z <Categories>.");
                return categoryColorMap;
            }

            IEnumerable<XElement> categories = rootElement.Elements("Category");

            foreach (XElement categoryElement in categories)
            {
                string name = categoryElement.Element("Name")?.Value; // Usamos ? para evitar null ref
                string colorHex = categoryElement.Element("Color")?.Value;

                if (string.IsNullOrEmpty(name))
                {
                    Debug.LogWarning("CategoryLoader.LoadCategoryInfo: Se encontr� una categor�a sin <Name>. Saltando.");
                    continue;
                }
                if (string.IsNullOrEmpty(colorHex))
                {
                    Debug.LogWarning($"CategoryLoader.LoadCategoryInfo: Categor�a '{name}' no tiene <Color>. Usando gris por defecto.");
                    colorHex = "#808080"; // Gris por defecto
                }


                Color categoryColor;
                if (UnityEngine.ColorUtility.TryParseHtmlString(colorHex, out categoryColor))
                {
                    if (!categoryColorMap.ContainsKey(name))
                    {
                        categoryColorMap.Add(name, categoryColor);
                    }
                    else
                    {
                        Debug.LogWarning($"CategoryLoader.LoadCategoryInfo: Nombre de categor�a duplicado '{name}' encontrado en {resourcePath}. Se usar� el primer color encontrado.");
                    }
                }
                else
                {
                    Debug.LogError($"CategoryLoader.LoadCategoryInfo: No se pudo parsear el color '{colorHex}' para la categor�a '{name}'. Usando negro por defecto.");
                    if (!categoryColorMap.ContainsKey(name))
                        categoryColorMap.Add(name, Color.black);
                }
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"CategoryLoader.LoadCategoryInfo: Error parseando XML '{resourcePath}': {e.Message}\n{e.StackTrace}");
        }

        return categoryColorMap;
    }    
    
   // M�todo para limpiar el cach� si necesitas recargar la configuraci�n
    public static void ClearCache()
    {
        s_categoryInfoCache = null;
        Debug.Log("CategoryLoader: Cache cleared.");
    }
}
